<?php
/**
 * Pestaña Widget — selección del widget a inyectar
 *
 * @package NexovaDeskChat
 * @var bool  $is_connected
 * @var array $cfg
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! $is_connected ) {
    echo '<div class="nexova-desk-card"><p>' . esc_html__( 'Conecta tu tienda primero en la pestaña Conexión.', 'nexova-desk-chat' ) . '</p></div>';
    return;
}

$selected_token = $cfg['widget_token'] ?? '';
$selected_id    = $cfg['widget_id'] ?? 0;
$selected_name  = $cfg['widget_name'] ?? '';
$orders_enabled = $cfg['orders_enabled'] ?? false;
?>

<div class="nexova-desk-card">
    <div class="nexova-desk-card__header">
        <h2><?php esc_html_e( 'Seleccionar widget', 'nexova-desk-chat' ); ?></h2>
        <button id="nexova-desk-refresh-widgets" class="nexova-desk-btn nexova-desk-btn--secondary nexova-desk-btn--sm">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="1.8" width="14" height="14">
                <path stroke-linecap="round" stroke-linejoin="round"
                      d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
            </svg>
            <?php esc_html_e( 'Actualizar lista', 'nexova-desk-chat' ); ?>
        </button>
    </div>

    <p class="nexova-desk-description">
        <?php esc_html_e( 'Elige el widget de Nexova Desk que deseas mostrar en tu tienda.', 'nexova-desk-chat' ); ?>
    </p>

    <div id="nexova-desk-widgets-list" class="nexova-desk-widgets-grid">
        <?php if ( $selected_token ) : ?>
        <div class="nexova-desk-widget-card is-selected"
             data-token="<?php echo esc_attr( $selected_token ); ?>"
             data-id="<?php echo esc_attr( $selected_id ); ?>"
             data-name="<?php echo esc_attr( $selected_name ); ?>">
            <div class="nexova-desk-widget-card__icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="1.8" width="20" height="20">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/>
                </svg>
            </div>
            <div class="nexova-desk-widget-card__body">
                <strong><?php echo esc_html( $selected_name ?: __( 'Widget seleccionado', 'nexova-desk-chat' ) ); ?></strong>
                <span class="nexova-desk-badge nexova-desk-badge--active">
                    <?php esc_html_e( 'Activo', 'nexova-desk-chat' ); ?>
                </span>
            </div>
            <div class="nexova-desk-widget-card__check">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5" width="16" height="16">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                </svg>
            </div>
        </div>
        <?php else : ?>
        <p class="nexova-desk-empty-state">
            <?php esc_html_e( 'Haz clic en "Actualizar lista" para cargar los widgets disponibles.', 'nexova-desk-chat' ); ?>
        </p>
        <?php endif; ?>
    </div>

    <input type="hidden" id="nexova-desk-widget-token" value="<?php echo esc_attr( $selected_token ); ?>" />
    <input type="hidden" id="nexova-desk-widget-id"    value="<?php echo esc_attr( $selected_id ); ?>" />
    <input type="hidden" id="nexova-desk-widget-name"  value="<?php echo esc_attr( $selected_name ); ?>" />

    <div id="nexova-desk-widgets-notice" class="nexova-desk-notice" style="display:none;"></div>
</div>

<div class="nexova-desk-card">
    <h2><?php esc_html_e( 'Pedidos WooCommerce', 'nexova-desk-chat' ); ?></h2>
    <p class="nexova-desk-description">
        <?php esc_html_e( 'Permite que el bot consulte el historial de pedidos del cliente desde el chat.', 'nexova-desk-chat' ); ?>
    </p>

    <label class="nexova-desk-toggle">
        <input type="checkbox" id="nexova-desk-orders-enabled"
               <?php checked( $orders_enabled ); ?> />
        <span class="nexova-desk-toggle__track"></span>
        <span class="nexova-desk-toggle__label">
            <?php esc_html_e( 'Activar consulta de pedidos', 'nexova-desk-chat' ); ?>
        </span>
    </label>

    <p class="description">
        <?php esc_html_e( 'Solo aplica a clientes con sesión activa en WooCommerce.', 'nexova-desk-chat' ); ?>
    </p>
</div>

<div class="nexova-desk-actions nexova-desk-actions--sticky">
    <button id="nexova-desk-save-widget" class="nexova-desk-btn nexova-desk-btn--primary">
        <?php esc_html_e( 'Guardar configuración', 'nexova-desk-chat' ); ?>
    </button>
    <span id="nexova-desk-save-widget-notice" class="nexova-desk-inline-notice" style="display:none;"></span>
</div>
