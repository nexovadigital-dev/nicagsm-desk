<?php
/**
 * Pestaña Conexión — estado de conexión con Nexova Desk
 *
 * @package NexovaDeskChat
 * @var bool   $is_connected
 * @var array  $org_data
 * @var string $server_url
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="nexova-desk-card">

    <?php if ( $is_connected ) : ?>

        <div class="nexova-desk-connected-state">
            <div class="nexova-desk-connected-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="1.8" width="40" height="40">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>

            <h2><?php esc_html_e( 'Conexión activa', 'nexova-desk-chat' ); ?></h2>

            <table class="nexova-desk-info-table">
                <tr>
                    <td><?php esc_html_e( 'Servidor', 'nexova-desk-chat' ); ?></td>
                    <td><code><?php echo esc_html( $server_url ); ?></code></td>
                </tr>
                <?php if ( ! empty( $org_data['name'] ) ) : ?>
                <tr>
                    <td><?php esc_html_e( 'Organización', 'nexova-desk-chat' ); ?></td>
                    <td><?php echo esc_html( $org_data['name'] ); ?></td>
                </tr>
                <?php endif; ?>
            </table>

            <div class="nexova-desk-actions">
                <button id="nexova-desk-disconnect-btn" class="nexova-desk-btn nexova-desk-btn--danger">
                    <?php esc_html_e( 'Desconectar', 'nexova-desk-chat' ); ?>
                </button>
            </div>
        </div>

    <?php else : ?>

        <div class="nexova-desk-connect-state">
            <h2><?php esc_html_e( 'Conectar con Nexova Desk', 'nexova-desk-chat' ); ?></h2>
            <p class="nexova-desk-description">
                <?php esc_html_e( 'Para comenzar, necesitas conectar tu tienda con tu cuenta de Nexova Desk. Al hacer clic en el botón, se abrirá una ventana de autenticación.', 'nexova-desk-chat' ); ?>
            </p>

            <div class="nexova-desk-server-field">
                <label for="nexova-desk-server-url">
                    <?php esc_html_e( 'URL del servidor Nexova Desk', 'nexova-desk-chat' ); ?>
                </label>
                <input
                    type="url"
                    id="nexova-desk-server-url"
                    class="regular-text"
                    placeholder="https://app.nexova.digital"
                    value="<?php echo esc_attr( $server_url ); ?>"
                />
                <p class="description">
                    <?php esc_html_e( 'La URL base de tu instalación de Nexova Desk.', 'nexova-desk-chat' ); ?>
                </p>
            </div>

            <div class="nexova-desk-actions">
                <button id="nexova-desk-connect-btn" class="nexova-desk-btn nexova-desk-btn--primary">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="1.8" width="16" height="16">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/>
                    </svg>
                    <?php esc_html_e( 'Conectar con Nexova Desk', 'nexova-desk-chat' ); ?>
                </button>
            </div>

            <div id="nexova-desk-connect-notice" class="nexova-desk-notice" style="display:none;"></div>
        </div>

    <?php endif; ?>

</div>

<?php if ( $is_connected ) : ?>
<div class="nexova-desk-card nexova-desk-card--muted">
    <h3><?php esc_html_e( '¿Qué hace este plugin?', 'nexova-desk-chat' ); ?></h3>
    <ul class="nexova-desk-feature-list">
        <li><?php esc_html_e( 'Inyecta el widget de chat de Nexova Desk en tu tienda', 'nexova-desk-chat' ); ?></li>
        <li><?php esc_html_e( 'Identifica automáticamente a clientes con sesión iniciada', 'nexova-desk-chat' ); ?></li>
        <li><?php esc_html_e( 'Permite consultar el estado de pedidos desde el chat', 'nexova-desk-chat' ); ?></li>
        <li><?php esc_html_e( 'Control total sobre en qué páginas aparece el widget', 'nexova-desk-chat' ); ?></li>
    </ul>
</div>
<?php endif; ?>
